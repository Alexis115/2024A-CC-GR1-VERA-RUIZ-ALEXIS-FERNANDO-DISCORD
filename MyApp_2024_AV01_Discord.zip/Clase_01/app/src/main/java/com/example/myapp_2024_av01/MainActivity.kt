package com.example.myapp_2024_av01

import android.app.Activity
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.content.Intent
import android.provider.ContactsContract
import android.widget.Button
import androidx.activity.result.contract.ActivityResultContracts
import com.google.android.material.snackbar.Snackbar
import android.net.Uri



class MainActivity : AppCompatActivity() {

    fun mostrarSnackbar(texto:String){
        val snack = Snackbar.make(
            findViewById(R.id.id_layout_main),
            texto,
            Snackbar.LENGTH_INDEFINITE
        )
        snack.show()
    }

    val callbackContenidoIntentExplicito =
        registerForActivityResult(
            ActivityResultContracts.StartActivityForResult()
        ){
            result ->
            if(result.resultCode == Activity.RESULT_OK){
                if(result.data != null){
                    //logica de negocio
                    val data = result.data
                    mostrarSnackbar(
                        "${data?.getStringExtra("nombreModificado")}"
                    )
                }
            }
        }

    val callbackContenidoIntentImplicito =
        registerForActivityResult(
            ActivityResultContracts.StartActivityForResult()
        ){
            result ->
            if(result.resultCode == Activity.RESULT_OK){
                if(result.data!!.data != null){
                    val uri: Uri = result.data!!.data!!
                    val cursor = contentResolver.query(
                        uri, null, null, null, null, null
                    )
                    cursor?.moveToFirst()
                    val indiceTelefono = cursor?.getColumnIndex(
                        ContactsContract.CommonDataKinds.Phone.NUMBER
                    )
                    val telefono = cursor?.getString(indiceTelefono!!)
                    cursor?.close(
                    )
                    mostrarSnackbar("Telefono $telefono")
                }
            }

        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        //Encontrar una vista (boton) por su id
        val botonCicloVida = findViewById<Button>(R.id.btn_ciclo_vida)
        //Añadir un listener al boton
        botonCicloVida
            //Iniciar una actividad al pulsar el boton
            .setOnClickListener{
                irActividad(ACicloVida::class.java)
            }

        //Encontrar una vista (boton) por su id
        val botonListView = findViewById<Button>(R.id.btn_ir_list_view)
        //Añadir un listener al boton
        botonListView
            //Iniciar una actividad al pulsar el boton
            .setOnClickListener{
                irActividad(BListView::class.java)
            }

        val botonIntentImplicito = findViewById<Button>(
            R.id.btn_ir_intent_implicito
        )
        botonIntentImplicito
            .setOnClickListener {
                val intentConRespuesta = Intent(
                    Intent.ACTION_PICK,
                    ContactsContract.CommonDataKinds.Phone.CONTENT_URI
                )
                callbackContenidoIntentImplicito.launch(intentConRespuesta)
            }

        val botonIntentExplicito = findViewById<Button>(
            R.id.btn_ir_intent_explicito
        )
        botonIntentExplicito
            .setOnClickListener {
                val intentExplicito = Intent(
                    this,
                    CIntentExplicitoParametros::class.java
                )
                //Enviar primitivas
                intentExplicito.putExtra("nombre", "Alexis")
                intentExplicito.putExtra("apellido", "Vera")
                intentExplicito.putExtra("edad", "27")
                //Para enviar la clase BEntrenador implementamos parcelable en BEntrenador.KT
                intentExplicito.putExtra(
                    "entrenador",
                    BEntrenador(10, "Alexis", "Vera")
                )
                callbackContenidoIntentExplicito.launch(intentExplicito)
            }


        //Inicializar Base de datos
        EBaseDeDatos.tablaEntrenador = ESqliteHelperEntrenador(
            this
        )

        //Encontrar una vista (boton) por su id
        val botonSqlite = findViewById<Button>(R.id.btn_sqlite)
        //Añadir un listener al boton
        botonSqlite.
            //Iniciar una actividad al pulsar el boton
            setOnClickListener {
                irActividad(ECrudEntrenador::class.java)
        }

        //Encontrar una vista (boton) por su id
        val botonRecyclerView = findViewById<Button>(R.id.btn_recycler_view)
        //Añadir un listener al boton
        botonRecyclerView.
            //Iniciar una actividad al pulsar el boton
        setOnClickListener {
            irActividad(FRecyclerView::class.java)
        }

        //Encontrar una vista (boton) por su id
        val botonGMaps = findViewById<Button>(R.id.btn_google_maps)
        //Añadir un listener al boton
        botonGMaps.
            //Iniciar una actividad al pulsar el boton
        setOnClickListener {
            irActividad(GGoogleMapsActivity::class.java)
        }

        //Encontrar una vista (boton) por su id
        val botonFirebaseUI = findViewById<Button>(R.id.btn_intent_firebase_ui)
        //Añadir un listener al boton
        botonFirebaseUI.
            //Iniciar una actividad al pulsar el boton
        setOnClickListener {
            irActividad(HFirebaseUIAuth::class.java)
        }

        //Encontrar una vista (boton) por su id
        val botonDeber02 = findViewById<Button>(R.id.btn_deber_02)
        //Añadir un listener al boton
        botonDeber02.
            //Iniciar una actividad al pulsar el boton
        setOnClickListener {
            irActividad(d2_recycler_view_discord::class.java)
        }



    }





    fun irActividad(
        clase: Class<*>
    ){
        val intent = Intent(this, clase);
        startActivity(intent)
    }
}