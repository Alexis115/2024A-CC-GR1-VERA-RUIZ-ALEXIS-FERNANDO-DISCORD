package com.example.myapp_2024_av01

class d2_RecyclerView_Adapt3 {
}